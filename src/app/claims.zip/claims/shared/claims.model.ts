
export class Claims {
    constructor(
    public id?: number,
    public name?: string,
    ){}
}